<%@ page import="java.sql.*" %>
<%@ page import="com.library.DBConnection" %>
<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("login.html");
        return;
    }
    int userId = (Integer) session.getAttribute("userId");
    String userName = (String) session.getAttribute("userName");
    int issuedCount = 0;
    double paid = 0;

    try (Connection con = DBConnection.getConnection()) {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COUNT(*) FROM issued_books WHERE user_id=? AND status='ISSUED'")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) issuedCount = rs.getInt(1); }
        }
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT COALESCE(SUM(amount),0) FROM payments WHERE user_id=? AND status='SUCCESS'")) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) paid = rs.getDouble(1); }
        }
    }
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard - LibTrack</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="topbar">
    <h2>📚 LibTrack</h2>
    <div><span>Hello, <%= userName %></span> <a href="index.html">Logout</a></div>
</nav>
<main class="container">
    <div class="welcome">
        <div><span class="badge">MEMBER DASHBOARD</span><h1>Welcome, <%= userName %> 👋</h1></div>
        <a class="btn" href="books">Browse Books</a>
    </div>

    <% if (request.getParameter("message") != null) { %>
        <div class="alert success"><%= request.getParameter("message") %></div>
    <% } %>

    <div class="stats">
        <div class="stat"><span>📚</span><strong><%= issuedCount %></strong><small>Books Issued</small></div>
        <div class="stat"><span>💳</span><strong>₹<%= String.format("%.2f", paid) %></strong><small>Total Payments</small></div>
        <div class="stat"><span>🔐</span><strong>Active</strong><small>Account Status</small></div>
    </div>

    <div class="grid">
        <a class="feature card" href="books"><b>📕 Browse Books</b><p>Explore available books and issue one.</p></a>
        <a class="feature card" href="issueBook.jsp"><b>📦 Issue Book</b><p>Enter a book ID to issue a book.</p></a>
        <a class="feature card" href="payment.jsp"><b>💳 Payments</b><p>Pay library fines or other charges.</p></a>
    </div>
</main>
</body>
</html>
