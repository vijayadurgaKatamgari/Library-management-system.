<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("login.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Payment - LibTrack</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body class="center-page">
<div class="card auth-card">
    <div class="logo">💳</div>
    <h1>Library Payment</h1>
    <p class="muted">Record a library fee payment securely.</p>
    <% if(request.getParameter("success") != null) { %>
        <div class="alert success">Payment successful. Reference: <%= request.getParameter("ref") %></div>
    <% } %>
    <form action="payment" method="post">
        <label>Amount (₹)</label>
        <input type="number" name="amount" min="1" step="0.01" required>
        <label>Payment Method</label>
        <select name="method" required>
            <option value="">Choose method</option>
            <option>UPI</option>
            <option>Debit Card</option>
            <option>Credit Card</option>
            <option>Net Banking</option>
            <option>Cash</option>
        </select>
        <button class="btn full" type="submit">Pay Now</button>
    </form>
    <p class="center"><a href="dashboard.jsp">← Dashboard</a></p>
</div>
</body>
</html>
