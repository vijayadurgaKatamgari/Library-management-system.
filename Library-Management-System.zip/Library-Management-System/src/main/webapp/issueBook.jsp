<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("login.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Issue Book - LibTrack</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body class="center-page">
<div class="card auth-card">
    <div class="logo">📦</div>
    <h1>Issue a Book</h1>
    <p class="muted">Books are issued for 14 days.</p>
    <% if(request.getParameter("error") != null) { %>
        <div class="alert error"><%= request.getParameter("error") %></div>
    <% } %>
    <form action="issueBook" method="post">
        <label>Book ID</label>
        <input type="number" name="bookId" min="1" value="<%= request.getParameter("bookId") == null ? "" : request.getParameter("bookId") %>" required>
        <button class="btn full" type="submit">Issue Book</button>
    </form>
    <p class="center"><a href="books">Browse Books</a> · <a href="dashboard.jsp">Dashboard</a></p>
</div>
</body>
</html>
