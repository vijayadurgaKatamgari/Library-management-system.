<%@ page import="java.util.*" %>
<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect("login.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Books - LibTrack</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="topbar">
    <h2>📚 LibTrack</h2>
    <div><a href="dashboard.jsp">Dashboard</a></div>
</nav>
<main class="container">
    <div class="page-head">
        <div><span class="badge">CATALOG</span><h1>Available Books</h1></div>
        <a class="btn secondary" href="dashboard.jsp">← Dashboard</a>
    </div>
    <div class="table-wrap">
    <table>
        <thead><tr><th>ID</th><th>Title</th><th>Author</th><th>Category</th><th>Available</th><th>Action</th></tr></thead>
        <tbody>
        <%= request.getAttribute("bookRows") == null ? "<tr><td colspan='6'>No books found.</td></tr>" : request.getAttribute("bookRows") %>
        </tbody>
    </table>
    </div>
</main>
</body>
</html>
